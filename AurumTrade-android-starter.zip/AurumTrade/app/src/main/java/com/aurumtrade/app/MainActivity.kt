package com.aurumtrade.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF081525)
private val Panel = Color(0xFF10243A)
private val Gold = Color(0xFFD6A84F)
private val Muted = Color(0xFF91A4B8)
private val Bull = Color(0xFF22C58B)
private val Bear = Color(0xFFEF5350)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AurumTradeApp() }
    }
}

@Composable
private fun AurumTradeApp() {
    var selected by remember { mutableStateOf("Dashboard") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            background = Navy,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val items = listOf(
                        "Dashboard" to Icons.Filled.Dashboard,
                        "Charts" to Icons.Filled.ShowChart,
                        "Scanner" to Icons.Filled.Radar,
                        "Signals" to Icons.Filled.Notifications,
                        "Research" to Icons.Filled.Psychology
                    )
                    items.forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = selected == label,
                            onClick = { selected = label },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold,
                                selectedTextColor = Gold,
                                indicatorColor = Navy,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                "Charts" -> PlaceholderScreen("Charts", "MT5-inspired chart workspace")
                "Scanner" -> PlaceholderScreen("Market Scanner", "Selected instruments and setup scans")
                "Signals" -> PlaceholderScreen("Trading Signals", "Validated setup alerts will appear here")
                "Research" -> PlaceholderScreen("Strategy Research", "Explore, test and compare strategies")
                else -> Dashboard(Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun Dashboard(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("AURUM", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("Trade smarter.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
                Surface(color = Panel, shape = RoundedCornerShape(50)) {
                    Text("V1 PREVIEW", color = Muted, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontSize = 10.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("MARKET OVERVIEW", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Text("Your trading workspace", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                    Text("Market data connection is not configured yet.", color = Muted, fontSize = 13.sp)
                    Text("DEVELOPMENT MODE · NO LIVE PRICES", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item { Text("WATCHLIST", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("XAUUSD", "EURUSD", "GBPUSD", "USDJPY", "US30", "NAS100").forEachIndexed { index, symbol ->
                    Row(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(symbol, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Awaiting market data", color = Muted, fontSize = 11.sp)
                        }
                        Text("—", color = if (index % 2 == 0) Bull else Bear, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("SIGNAL ENGINE", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("No signals generated", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Signals require a configured market-data source and validated strategy rules.", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun PlaceholderScreen(title: String, description: String) {
    Column(
        Modifier.fillMaxSize().background(Navy).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(description, color = Muted)
        Spacer(Modifier.height(18.dp))
        Text("FOUNDATION SCREEN · IN DEVELOPMENT", color = Muted, fontSize = 10.sp)
    }
}

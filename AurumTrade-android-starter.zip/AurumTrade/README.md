# AurumTrade

Android-first market analysis, strategy research and trading signals platform.

## Version 1 scope
- Market analysis and charting
- Selected-instrument scanning
- Strategy research, testing and comparison
- Signal generation and notifications
- Historical backtesting where data is available

Broker execution, live account connectivity, copy trading and fund movement are deferred to future versions.

## Approved architecture
- Android: Kotlin + Jetpack Compose
- Chart engine: TradingView Lightweight Charts in Android WebView (planned integration)
- API: Python + FastAPI
- Data layer: Supabase (planned integration)
- CI: GitHub Actions

## Initial scanner watchlist
XAUUSD, EURUSD, GBPUSD, USDJPY, US30, NAS100

## Build status
This is the initial Android UI and API foundation. It does not yet connect to a live market-data feed and does not place trades. Prices and signals are intentionally not fabricated.

## Build
Use JDK 17, Android SDK 35 and Gradle 8.9, then run `gradle assembleDebug`.
The GitHub Actions workflow builds and uploads a debug APK artifact.

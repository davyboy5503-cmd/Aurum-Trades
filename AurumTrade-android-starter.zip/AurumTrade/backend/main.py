from fastapi import FastAPI

app = FastAPI(
    title="AurumTrade API",
    version="0.1.0",
    description="Market analysis, strategy research and signal services.",
)

@app.get("/health")
def health():
    return {"status": "ok", "service": "aurumtrade-api", "mode": "development"}

@app.get("/v1/instruments")
def instruments():
    return {"instruments": ["XAUUSD", "EURUSD", "GBPUSD", "USDJPY", "US30", "NAS100"]}
